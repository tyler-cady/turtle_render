from .turtle_render import draw_ai_image

if __name__ == "__main__":
    draw_ai_image()
