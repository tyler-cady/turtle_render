#__init__.py


from .gen import generate
from .turtle_render import draw_ai_image